/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package todolist;

/**
 *
 * @author Mario Abraham
 */


import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class ToDoListApplicatonFrame extends JFrame {

    private final List<Task> taskList = new ArrayList<>();
    private final List<Category> categoryList = new ArrayList<>();
    private TaskTableModel tableModel;
    private JTable taskTable;
    private TableRowSorter<TaskTableModel> sorter;

    public ToDoListApplicatonFrame() {
        setTitle("Group Project To-Do List");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Add sample data
        initializeData();

        // Setup UI
        initUI();
    }

    private void initializeData() {
            // Sample Categories
            Category catGui = new Category("GUI");
            Category catModel = new Category("System Modeling");
            Category catDocs = new Category("Documentation");
            Category catTesting = new Category("Testing");        
            Category catDatabase = new Category("Database");     

            categoryList.add(catGui);
            categoryList.add(catModel);
            categoryList.add(catDocs);
            categoryList.add(catTesting);                     
            categoryList.add(catDatabase);                        

            // Sample Tasks (you can add tasks for your new categories here too)
            taskList.add(new Task("Design Main Frame", "Design the main window layout.", LocalDate.now().plusDays(5), Priority.HIGH, catGui));
            taskList.add(new Task("Create Class Diagram", "Draw the final UML class diagram.", LocalDate.now().plusDays(2), Priority.HIGH, catModel));
            taskList.add(new Task("Write User Manual", "Document all features for the user.", LocalDate.now().plusDays(10), Priority.MEDIUM, catDocs));
            taskList.add(new Task("Implement Button Listeners", "Add action listeners to all buttons.", LocalDate.now().plusDays(7), Priority.MEDIUM, catGui));
            taskList.get(2).setStatus(Status.COMPLETED); 
        }

    private void initUI() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Top panel for controls
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton addButton = new JButton("Add Task");
        JButton updateButton = new JButton("Update Task");
        JButton deleteButton = new JButton("Delete Task");
        controlPanel.add(addButton);
        controlPanel.add(updateButton);
        controlPanel.add(deleteButton);

        // Filter Controls
        controlPanel.add(new JLabel("   Filter by Category:"));
        JComboBox<Category> categoryFilter = new JComboBox<>(categoryList.toArray(new Category[0]));
        categoryFilter.insertItemAt(new Category("All"), 0);
        categoryFilter.setSelectedIndex(0);
        controlPanel.add(categoryFilter);

        controlPanel.add(new JLabel("   Show:"));
        JComboBox<String> statusFilter = new JComboBox<>(new String[]{"All", "Pending", "Completed"});
        controlPanel.add(statusFilter);

        mainPanel.add(controlPanel, BorderLayout.NORTH);

        // Table setup
        tableModel = new TaskTableModel(taskList);
        taskTable = new JTable(tableModel);
        sorter = new TableRowSorter<>(tableModel);
        taskTable.setRowSorter(sorter);
        taskTable.setFillsViewportHeight(true);
        taskTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        taskTable.setRowHeight(25);
        taskTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 14));
        
        // Custom renderer to color rows based on status
        taskTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                int modelRow = table.convertRowIndexToModel(row);
                if (taskList.get(modelRow).getStatus() == Status.COMPLETED) {
                    c.setBackground(new Color(220, 255, 220)); // Light green
                } else {
                    c.setBackground(table.getBackground());
                }
                if (isSelected) {
                    c.setBackground(table.getSelectionBackground());
                }
                return c;
            }
        });


        mainPanel.add(new JScrollPane(taskTable), BorderLayout.CENTER);

        // Action Listeners
        addButton.addActionListener(e -> showTaskDialog(null));
        
        updateButton.addActionListener(e -> {
            int selectedRow = taskTable.getSelectedRow();
            if (selectedRow >= 0) {
                int modelIndex = taskTable.convertRowIndexToModel(selectedRow);
                showTaskDialog(taskList.get(modelIndex));
            } else {
                JOptionPane.showMessageDialog(this, "Please select a task to update.", "No Task Selected", JOptionPane.WARNING_MESSAGE);
            }
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = taskTable.getSelectedRow();
            if (selectedRow >= 0) {
                int modelIndex = taskTable.convertRowIndexToModel(selectedRow);
                int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this task?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
                if (choice == JOptionPane.YES_OPTION) {
                    taskList.remove(modelIndex);
                    tableModel.fireTableDataChanged();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a task to delete.", "No Task Selected", JOptionPane.WARNING_MESSAGE);
            }
        });
        
        // Filter Action Listener
        Action applyFilters = new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                List<RowFilter<Object, Object>> filters = new ArrayList<>();
                
                // Category filter
                Category selectedCategory = (Category) categoryFilter.getSelectedItem();
                if (selectedCategory != null && !selectedCategory.getName().equals("All")) {
                    filters.add(RowFilter.regexFilter("^" + selectedCategory.getName() + "$", 1));
                }

                // Status filter
                String status = statusFilter.getSelectedItem().toString();
                if (!status.equals("All")) {
                    filters.add(RowFilter.regexFilter("^" + status + "$", 4));
                }

                sorter.setRowFilter(RowFilter.andFilter(filters));
            }
        };
        categoryFilter.addActionListener(applyFilters);
        statusFilter.addActionListener(applyFilters);


        add(mainPanel);
    }

    private void showTaskDialog(Task taskToUpdate) {
        JDialog dialog = new JDialog(this, (taskToUpdate == null ? "Add New Task" : "Update Task"), true);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.setSize(400, 500);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Form Fields
        JTextField titleField = new JTextField(20);
        JTextArea descArea = new JTextArea(5, 20);
        JTextField dueDateField = new JTextField(10);
        dueDateField.setText("YYYY-MM-DD");
        JComboBox<Priority> priorityBox = new JComboBox<>(Priority.values());
        JComboBox<Category> categoryBox = new JComboBox<>(categoryList.toArray(new Category[0]));
        JComboBox<Status> statusBox = new JComboBox<>(Status.values());

        // Layouting with GridBagLayout
        gbc.gridx = 0; gbc.gridy = 0; formPanel.add(new JLabel("Title:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1.0; formPanel.add(titleField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.NORTHWEST; formPanel.add(new JLabel("Description:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1; gbc.weighty = 1.0; gbc.fill = GridBagConstraints.BOTH; formPanel.add(new JScrollPane(descArea), gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.weighty = 0; gbc.fill = GridBagConstraints.HORIZONTAL; formPanel.add(new JLabel("Due Date:"), gbc);
        gbc.gridx = 1; gbc.gridy = 2; formPanel.add(dueDateField, gbc);

        gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Priority:"), gbc);
        gbc.gridx = 1; gbc.gridy = 3; formPanel.add(priorityBox, gbc);

        gbc.gridx = 0; gbc.gridy = 4; formPanel.add(new JLabel("Category:"), gbc);
        gbc.gridx = 1; gbc.gridy = 4; formPanel.add(categoryBox, gbc);

        if (taskToUpdate != null) {
            gbc.gridx = 0; gbc.gridy = 5; formPanel.add(new JLabel("Status:"), gbc);
            gbc.gridx = 1; gbc.gridy = 5; formPanel.add(statusBox, gbc);
        }

        // Pre-fill form if updating
        if (taskToUpdate != null) {
            titleField.setText(taskToUpdate.getTitle());
            descArea.setText(taskToUpdate.getDescription());
            dueDateField.setText(taskToUpdate.getDueDate().toString());
            priorityBox.setSelectedItem(taskToUpdate.getPriority());
            categoryBox.setSelectedItem(taskToUpdate.getCategory());
            statusBox.setSelectedItem(taskToUpdate.getStatus());
        }

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        saveButton.addActionListener(e -> {
            try {
                String title = titleField.getText();
                String desc = descArea.getText();
                LocalDate dueDate = LocalDate.parse(dueDateField.getText());
                Priority priority = (Priority) priorityBox.getSelectedItem();
                Category category = (Category) categoryBox.getSelectedItem();

                if (title.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "Title cannot be empty.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (taskToUpdate == null) { // Creating a new task
                    Task newTask = new Task(title, desc, dueDate, priority, category);
                    taskList.add(newTask);
                } else { // Updating an existing task
                    taskToUpdate.setTitle(title);
                    taskToUpdate.setDescription(desc);
                    taskToUpdate.setDueDate(dueDate);
                    taskToUpdate.setPriority(priority);
                    taskToUpdate.setCategory(category);
                    taskToUpdate.setStatus((Status)statusBox.getSelectedItem());
                }
                tableModel.fireTableDataChanged();
                dialog.dispose();

            } catch (DateTimeParseException ex) {
                JOptionPane.showMessageDialog(dialog, "Invalid date format. Please use YYYY-MM-DD.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        cancelButton.addActionListener(e -> dialog.dispose());

        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }
    
    public static void main(String[] args) {
        // Run the GUI in the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            new ToDoListApplicatonFrame().setVisible(true);
        });
    }
}
