/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package todolist;

/**
 *
 * @author Mario Abraham
**/

import javax.swing.table.AbstractTableModel;
import java.util.List;
import java.time.format.DateTimeFormatter;

public class TaskTableModel extends AbstractTableModel {

    private final List<Task> tasks;
    private final String[] columnNames = {"Title", "Category", "Due Date", "Priority", "Status"};
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public TaskTableModel(List<Task> tasks) {
        this.tasks = tasks;
    }

    @Override
    public int getRowCount() {
        return tasks.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Task task = tasks.get(rowIndex);
        switch (columnIndex) {
            case 0: return task.getTitle();
            case 1: return task.getCategory().getName();
            case 2: return task.getDueDate().format(formatter);
            case 3: return task.getPriority();
            case 4: return task.getStatus();
            default: return null;
        }
    }
}